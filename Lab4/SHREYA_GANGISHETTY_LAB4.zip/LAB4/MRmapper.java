package youtube;

import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MRmapper  extends Mapper <LongWritable,Text,Text,Text> {
	static String IFS=",";
    static String OFS=",";
    static int NF=11;
    public void map(LongWritable key, Text value, Context context) 
                    throws IOException, InterruptedException {
/*     USvideos.cs, --video_id 0,title 1,channel_title 2,---category_id 3 ,tags 4
       --- views 5, likes 6, dislikes 7, comment_total 8, --- thumbnail_link 9
        date 10, first offset of the split is the key 11,	value is the inputFile 12 all files
*/
    	
    	// TODO 1: remove schema line

           if (key.get() == 0 )
                 return;// Does not write anything if the first key is 0 that is header for USvideos.csv file
             else {
                 // If key is not 0 then the data is validated and sent to reducer
       // TODO 2: convert value to string
            	 String splitLine[] =value.toString().split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
       // TODO 3: count num fields, increment bad record counter, and return if bad
            	if (splitLine.length != NF)
            	{// not counting the row with bad columns
            		return;
            	}
       // TODO 4: pull out fields of interest
       // TODO 5: construct key and composite value
            	Text output_key =new Text (splitLine[3]);
            	Text output_value = new Text(splitLine[0]+","+splitLine[5]+","+splitLine[6]+","+splitLine[7]+","+splitLine[9]);
       // TODO 6: write key value pair to context
            	context.write(output_key, output_value);
            	//context.write(new Text (splitLine[3]), new Text(splitLine[0]+","+splitLine[5]+","+splitLine[6]+","+splitLine[7]+","+splitLine[9]));
             }
    }
}