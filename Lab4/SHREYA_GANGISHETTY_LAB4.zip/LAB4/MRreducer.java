package youtube;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MRreducer  extends Reducer <Text,Text,Text,Text> {
	public static String IFS=",";
    public static String OFS=",";
    
	public void reduce(Text key, Iterable<Text> values, Context context) 
		   throws IOException, InterruptedException {
	 
	// TODO 1: initialize variables	
	 long tempViews = 0L,tempLikes = 0L,tempDislikes =0L;
	 long max_views=Long.MIN_VALUE, max_likes=Long.MIN_VALUE, max_dislikes=Long.MIN_VALUE;
	 Text views_Video_id=null, views_Thumbnail_link=null,
		  likes_Video_id=null, likes_Thumbnail_link=null,
		  dislikes_Video_id=null, dislikes_Thumbnail_link=null;
	 String compositeString;
	 String[] compositeStringArray;
	 
	// TODO 2: loop through values to find most viewed, most liked, and most disliked video
	 for (Text value: values)
	 { 
		 compositeString = value.toString();
		 compositeStringArray = compositeString.split(",");
		 //Array position: v_id 0 views 1 likes 2 dislikes 7 thumbnail_link 9
		 
		 tempViews = Long.parseLong(compositeStringArray[1]);
		 tempLikes = Long.parseLong(compositeStringArray[2]);
		 tempDislikes = Long.parseLong(compositeStringArray[3]);
		// finding max views and storing its corresponding Video Id and Thumbnail link 
		 if(tempViews > max_views)
		 { 
	     	 max_views=tempViews;
			 views_Video_id = new Text(compositeStringArray[0]);
			 views_Thumbnail_link = new Text(compositeStringArray[4]);
		  }
	    // finding max Likes and storing its corresponding Video Id and Thumbnail link 
		 if(tempLikes > max_likes)
		 {   
			 max_likes=tempLikes;
			 likes_Video_id = new Text(compositeStringArray[0]);
			 likes_Thumbnail_link = new Text(compositeStringArray[4]);
		  }
		// finding max Likes and storing its corresponding Video Id and Thumbnail link		 
		 if(tempDislikes > max_dislikes)
		 { 
			 max_dislikes=tempDislikes;
			 dislikes_Video_id = new Text(compositeStringArray[0]);
			 dislikes_Thumbnail_link = new Text(compositeStringArray[4]);
		 }
	 } 
	
	// TODO 3: write the key-value pair to the context exactly as defined in lab write-up
	 Text keyText = new Text("category_id: " + key.toString());
	 Text valueText = new Text("\nmost views: " + views_Video_id+","+ views_Thumbnail_link
	 +"\n"+ "most likes: " +likes_Video_id+","+ likes_Thumbnail_link
	 +"\n"+ "most dislikes: " + dislikes_Video_id+","+ dislikes_Thumbnail_link);
	 
	 context.write(keyText, valueText); 
   }
}